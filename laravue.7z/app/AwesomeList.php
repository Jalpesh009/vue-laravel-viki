<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AwesomeList extends Model
{
    protected $fillable = ['name', 'email'];
}
